# K's Kitchen Android — Cloud APK Build

See `README-CLOUD-BUILD.md` for the phone-only GitHub Actions build procedure.

The included workflow is `.github/workflows/build-apk.yml` and builds `Ks-Kitchen.apk` as a downloadable GitHub Actions artifact.
