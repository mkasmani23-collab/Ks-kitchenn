# K's Kitchen — Free Cloud APK Build

This project is prepared to build the Android debug APK using GitHub Actions. Android Studio is NOT required on the phone or on your computer for the cloud build.

## Phone-only steps

1. Create/sign in to a GitHub account at https://github.com/ .
2. Create a new repository. A public repository is the simplest free option for GitHub-hosted Actions.
3. Upload the contents of this project to the repository. The repository root must contain `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, and `.github`.
4. Open the repository's **Actions** tab.
5. Select **Build K's Kitchen APK**.
6. Tap **Run workflow** and run it on the `main` branch.
7. Wait for the green successful run.
8. Open that workflow run and scroll to **Artifacts**.
9. Download **Ks-Kitchen-debug-APK**.
10. Extract the downloaded ZIP on the phone if necessary and install `Ks-Kitchen.apk`.

## Important

- This is a debug APK for testing/own-device installation.
- It is not a Play Store release build.
- The app keeps the current K's Kitchen HTML functionality, including delivery date/time slot and WhatsApp reminder support.
- The launcher icon is included as a simple K's Kitchen branded vector icon.
- GitHub Actions builds on a hosted Linux runner; no Android Studio is required for the cloud build.
